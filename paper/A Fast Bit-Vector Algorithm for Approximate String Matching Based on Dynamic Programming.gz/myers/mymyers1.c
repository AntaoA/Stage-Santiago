// My book version (almost)
#include <stdio.h>
#include <sys/file.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

#define WORD long

#define SIGMA    128
#define BUF_MAX 2048

#include "parse.i"

unsigned WORD Pc[SIGMA];

void setup_search()
{ unsigned WORD One;
  register int a, p;
  void error();

  if (patlen > 8*sizeof(unsigned WORD))
    error("Pattern is longer than %d\n elements",8*sizeof(unsigned WORD));
  for (a = 0; a < SIGMA; a++)
    Pc[a] = 0;
  One = 1;
  for (p = 0; p < patlen; p++)
    { if (patvec[p].type == CHAR)
        Pc[*(patvec[p].value)] |= One;
      else
        for (a = 0; a < SIGMA; a++)
          if (patvec[p].value[a>>3] & 1<<a%8)
            Pc[a] |= One;
      One <<= 1;
    }

#ifdef SHOW
  One = 1;
  for (a = 0; a < SIGMA; a++)
    { if (isprint(a))
        printf("  %c: ",a);
      else
        printf("%3d: ",a);
      for (p = 0; p < patlen; p++)
        if (Pc[a] & (One<<p))
          printf("1");
        else
          printf("0");
      printf("\n");
    }
#endif
}

static int cnt = 0;

void report(int pos)
{ cnt += 1; }

void search(ifile,dif) int ifile, dif;
{ register unsigned WORD D0,VN,VP,HN,HP,A,Ebit;
  unsigned WORD One;
  register int Cscore,i;
  int a, p, num, base; 
  static char buf[BUF_MAX];

  Ebit = (1 << (patlen-1));
  VP    = -1;
  VN    = 0;
  Cscore = patlen-dif-1;

  for (base = 1; (num = read(ifile,buf,BUF_MAX)) > 0; base += num)
    { for (i = 0; i < num; i++)
        { 
	  A  = Pc[buf[i]] | VN;
	  D0 = ((VP + (VP&A)) ^ VP) | A;
   	  HN = VP & D0;
	  HP = VN | ~ (VP | D0);

          if (HP & Ebit)
            Cscore += 1;
          else if (HN & Ebit)
            Cscore -= 1;
          if (Cscore < 0)
            report(base+i);

	  HP <<= 1;
	  VN = HP & D0;
	  VP = (HN<<1) | ~ (HP | D0);

#ifdef SHOW
	  a = buf[i];
          if (isprint(a))
            printf("  %c: ",a);
          else
            printf("%3d: ",a);

          printf("U   =");
          for (p = 0; p < patlen; p++)
            if (U & (1 << p))
              printf("  1");
            else
              printf("  0");
          printf("\n     ");

          printf("X   =");
          for (p = 0; p < patlen; p++)
            if (X & (1 << p))
              printf("  1");
            else
              printf("  0");
          printf("\n     ");

          printf("Col =");
          for (p = 0; p < patlen; p++)
            if (P & (1 << p))
              printf(" +1");
            else if (M & (1 << p))
              printf(" -1");
            else
              printf("  0");
          printf("\n\n");
#endif
        }
    }

}

#include "main.i"
