#include <stdio.h>
#include <sys/file.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

#define SIGMA    128
#define BUF_MAX 2048

#include "parse.i"

static int W;

void setup_search()
{ W = 8*sizeof(unsigned int); }

static int J, lr, lc;

static unsigned int M1, M2, M3, Din, G;

static unsigned int *Tm[SIGMA];

void dynamic_setup(int dif)
{ register unsigned int t, f, *b, one, con;
  unsigned int Pc[SIGMA];
  register int j, i, a, p, k;
  int  lrp1;
  void error();

  if (dif+1 >= W)
    error("Pattern diagonal does not fit in a word\n");

  lr   = dif + 1;
  lrp1 = lr+1;
  lc   = W/lrp1;
  J    = ((patlen-dif) - 1)/lc;

  M3 = 1;
  for (i = 0; i < dif; i++)
    M3 = (M3 << 1) | 1;

  Din = M3;
  for (i = 1; i < lc; i++)
    Din |= (Din << lrp1);

  M1 = 1;
  for (i = 1; i < lc; i++)
    M1 |= (M1 << lrp1);

  M2 = M1 | M3;

  j = (lc - (patlen-dif) % lc) %lc;
  G = (1 << (lrp1*j + dif));

  b = (unsigned int *) malloc(sizeof(unsigned int)*SIGMA*(J+1));

  for (a = 0; a < SIGMA; a++)
    { Tm[a] = b;
      b += (J+1);
    }

  for (j = 0; j <= J; j++)
    { for (a = 0; a < SIGMA; a++)
        Pc[a] = -1;

      k = lc*j + lr + lc - 1;
      if (k > patlen) k = patlen;
      one = 1;
      for (p = lc*j; p < k; p++)
        { con = ~one;
          if (patvec[p].type == CHAR)
            Pc[*(patvec[p].value)] &= con;
          else
            for (a = 0; a < SIGMA; a++)
              if (patvec[p].value[a>>3] & 1<<a%8)
                Pc[a] &= con;
          one <<= 1;
        }

     for (a = 0; a < SIGMA; a++)
       { f = Pc[a];
         t = 0;
         for (i = 0; i < lc; i++)
           { t = (t << lrp1) | (f & M3);
             f >>= 1;
           }
         Tm[a][j] = t;
       }
    }

#ifdef SHOW
  printf(" M1: ");
  for (p = lc*lrp1-1; p >= 0; p--)
    if (M1 & (1<<p))
      printf("1");
    else
      printf("0");
  printf("\n");

  printf(" M2: ");
  for (p = lc*lrp1-1; p >= 0; p--)
    if (M2 & (1<<p))
      printf("1");
    else
      printf("0");
  printf("\n");

  printf(" M3: ");
  for (p = lc*lrp1-1; p >= 0; p--)
    if (M3 & (1<<p))
      printf("1");
    else
      printf("0");
  printf("\n");

  printf("Din: ");
  for (p = lc*lrp1-1; p >= 0; p--)
    if (Din & (1<<p))
      printf("1");
    else
      printf("0");
  printf("\n");

  printf("  G: ");
  for (p = lc*lrp1-1; p >= 0; p--)
    if (G & (1<<p))
      printf("1");
    else
      printf("0");
  printf("\n");

  for (a = 0; a < SIGMA; a++)
    { if (isprint(a))
        printf("  %c: ",a);
      else
        printf("%3d: ",a);
      for (j = 0; j <= J; j++)
        { printf("[%d] = ",j);
          for (p = lc*lrp1-1; p >= 0; p--)
            if (Tm[a][j] & (1<<p))
              printf("1");
            else
              printf("0");
          printf("\n     ");
        }
      printf("\n");
    }

  fflush(stdout);
#endif
}

void search(ifile,dif) int ifile, dif;
{ register unsigned int *D, X, C, P, N, *e;
  int lrp1, lrp2, ld, ldm1;
  int i, j, num, base; 
  static char buf[BUF_MAX];

  dynamic_setup(dif);

  lrp1 = lr+1;
  lrp2 = lr+2;
  ld   = lrp1*(lc-1);
  ldm1 = ld - 1;

  D  = (unsigned int *) malloc(sizeof(unsigned int)*(J+1));

  for (j = 0; j <= J; j++)
    D[j] = Din;

  for (base = 1; (num = read(ifile,buf,BUF_MAX)) > 0; base += num)
    { for (i = 0; i < num; i++)
        { e  = Tm[buf[i]];

          C = D[0];
          X = (C >> lrp1) | *e++;
          if (J == 0)
            D[0] = ( (C << 1) | M1) 
                 & ( (C << lrp2) | M2 )
                 & (((X + M1) ^ X) >> 1) & Din;
          else
            { N = D[1];
              D[0] = ( (C << 1) & ( (C << lrp2) | (N >> ldm1) ) | M1 )
                   & (((X + M1) ^ X) >> 1) & Din;
              for (j = 1; j < J; j++)
                { P = C;
                  C = N;
                  N = D[j+1];
                  X = (C >> lrp1) | (P << ld) | *e++;
                  D[j] = ( (C << 1) & ( (C << lrp2) | (N >> ldm1) ) | M1 )
                       & (((X + M1) ^ X) >> 1) & Din;
                }
              X = (N >> lrp1) | (C << ld) | *e;
              D[J] = ( (N << 1) | M1) 
                   & ( (N << lrp2) | M2 )
                   & (((X + M1) ^ X) >> 1) & Din;
            }

          if ((D[J] & G) == 0)
            /* printf("  Match at %d\n",base+i) */; 

#ifdef SHOW
        { int p;
          if (isprint(buf[i]))
            printf("  %c: ",buf[i]);
          else
            printf("%3d: ",buf[i]);

          for (j = 0; j <= J; j++)
            { printf("D[%d] =",j);
              C = D[j];
              for (p = lc*lrp1-1; p >= 0; p--)
                if (C & (1 << p))
                  printf("1");
                else
                  printf("0");
              printf("\n     ");
            }
          printf("\n");
        }
#endif
        }
    }

}

#include "main.i"
