#include <stdio.h>

void main()
{ int W, X, lpr2, lc, m, k;
 
  W = 8*sizeof(unsigned long);
  for (k = 0; k <= 62; k++)
    { printf("%2d:",k);
      for (X = 1; X <= 10; X++)
        { lpr2 = k+2;
          lc   = W/lpr2;
          m    = lc*X + k;
          printf(" %3d",m);
        }
      printf("\n");
    }
}
