//
// Created by Dustin Cobas <dustin.cobas@gmail.com> on 8/16/20.
//

#ifndef SRI_BENCHMARK_DEFINITIONS_H_
#define SRI_BENCHMARK_DEFINITIONS_H_

#include <string>

namespace sri {

const std::string KEY_BWT_RLE = "bwt_rle";

const std::string KEY_BWT_HEADS = "bwt_heads";
const std::string KEY_BWT_HEADS_TEXT_POS = "bwt_heads_tpos";
const std::string KEY_BWT_TAILS = "bwt_tails";
const std::string KEY_BWT_TAILS_TEXT_POS = "bwt_tails_tpos";

const std::string KEY_BWT_HEADS_SAMPLED_TEXT_POS = "bwt_heads_sampled_tpos";
const std::string KEY_BWT_TAILS_TEXT_POS_SAMPLED = "bwt_tails_sampled_tpos";
//const std::string KEY_BWT_TAILS_MARKED_SAMPLED_IDX = "bwt_tails_marked_sampled_idx";

const std::string KEY_BWT_TAILS_SAMPLED_IDX_BY_HEAD_IN_TEXT = "bwt_tails_sampled_idx_by_heads_tpos";
const std::string KEY_BWT_TAILS_MARKED_SAMPLED_IDX_BY_HEAD_IN_TEXT = "bwt_tails_marked_sampled_idx_by_heads_tpos";
const std::string KEY_BWT_HEADS_MARKED_SAMPLED_TRUSTED_AREA_IN_TEXT = "bwt_heads_marked_sampled_trusted_area";

const std::string KEY_BWT_HEADS_TEXT_POS_SORTED_IDX = "bwt_heads_tpos_sorted_idx";
const std::string KEY_BWT_TAILS_TEXT_POS_SORTED_IDX = "bwt_tails_tpos_sorted_idx";
const std::string KEY_BWT_TAILS_SAMPLED_IDX = "bwt_tails_sampled_idx";

const std::string KEY_F = "f";

}

#endif //SRI_BENCHMARK_DEFINITIONS_H_
