RI: Index based on BWT-runs
=====

